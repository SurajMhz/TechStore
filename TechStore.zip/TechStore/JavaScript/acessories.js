  console.log("laptop");
  let page="all";
    idElement("accessories");
  