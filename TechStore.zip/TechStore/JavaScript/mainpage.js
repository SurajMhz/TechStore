  console.log("main");
    idElement("offer");
    idElement("topSold");
    idElement("laptops");
    idElement("computers");
    idElement("accessories");
  

  